const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Plugins.TiledBg,
		C3.Behaviors.solid,
		C3.Plugins.Keyboard,
		C3.Plugins.Text,
		C3.Plugins.Audio,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Keyboard.Cnds.OnKey,
		C3.Behaviors.Platform.Cnds.IsOnFloor,
		C3.Plugins.Sprite.Acts.SetAnim,
		C3.Plugins.System.Acts.SetBoolVar,
		C3.Plugins.Sprite.Cnds.OnAnimFinished,
		C3.Plugins.Sprite.Acts.SetMirrored,
		C3.Behaviors.Platform.Cnds.IsFalling,
		C3.Plugins.System.Cnds.Else,
		C3.Behaviors.Platform.Cnds.IsJumping,
		C3.Plugins.Sprite.Cnds.CompareY,
		C3.Behaviors.Platform.Cnds.IsMoving,
		C3.Plugins.System.Cnds.CompareBoolVar,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.System.Acts.SetVar,
		C3.Plugins.Audio.Acts.Play,
		C3.Plugins.System.Cnds.Every,
		C3.Plugins.System.Cnds.Compare,
		C3.Plugins.System.Exps.len,
		C3.Plugins.System.Exps.left,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Acts.GoToLayout
	];
};
self.C3_JsPropNameTable = [
	{Plataforma: 0},
	{CentrarEm: 0},
	{Jogador: 0},
	{Sólido: 0},
	{PlanoDeFundoEmBlocos: 0},
	{Tomate: 0},
	{Teclado: 0},
	{TextoInicial: 0},
	{Áudio: 0},
	{Sprite: 0},
	{isAttacking: 0},
	{canMove: 0},
	{fullText: 0},
	{textIndex: 0}
];

self.InstanceType = {
	Jogador: class extends self.ISpriteInstance {},
	PlanoDeFundoEmBlocos: class extends self.ITiledBackgroundInstance {},
	Tomate: class extends self.ISpriteInstance {},
	Teclado: class extends self.IInstance {},
	TextoInicial: class extends self.ITextInstance {},
	Áudio: class extends self.IInstance {},
	Sprite: class extends self.ISpriteInstance {}
}